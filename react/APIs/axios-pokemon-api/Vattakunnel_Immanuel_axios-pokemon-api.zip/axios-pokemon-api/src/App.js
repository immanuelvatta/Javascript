import './App.css';
import PokemonListWAxios from './components/PokemonListWAxios';

function App() {
  return (
    <div className="App">
      <PokemonListWAxios/>
    </div>
  );
}

export default App;
