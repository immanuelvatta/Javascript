import './App.css';
import APIWalker from './views/APIWalker';

function App() {
  return (
    <div className="App">
      <APIWalker/>
    </div>
  );
}

export default App;
