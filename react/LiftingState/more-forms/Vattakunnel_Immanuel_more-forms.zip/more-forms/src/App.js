import logo from './logo.svg';
import './App.css';
import UserForm from './components/UserForm';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <UserForm/>
      </header>
    </div>
  );
}

export default App;
