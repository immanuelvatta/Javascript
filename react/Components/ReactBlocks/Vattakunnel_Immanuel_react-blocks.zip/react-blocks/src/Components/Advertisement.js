import React from 'react'
import styles from './Advertisement.module.css'

const Advertisement = () => {
    return (
        <div className={styles.advertisement}>Advertisement</div>
    )
}

export default Advertisement
