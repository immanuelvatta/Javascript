import React from 'react';
import styles from './SubContents.module.css'

const SubContents = () => {
    return (
        <div className={styles.subContents}>Test</div>
    )
}

export default SubContents
